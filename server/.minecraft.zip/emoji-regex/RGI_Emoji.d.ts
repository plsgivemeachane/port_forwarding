declare module 'emoji-regex/RGI_Emoji' {
  function emojiRegex(): RegExp;

  export = emojiRegex;
}
