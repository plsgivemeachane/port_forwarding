# Installation
> `npm install --save @types/readdir-glob`

# Summary
This package contains type definitions for readdir-glob (https://github.com/Yqnn/node-readdir-glob).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/readdir-glob.

### Additional Details
 * Last updated: Mon, 20 Nov 2023 23:36:24 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Dolan Miu](https://github.com/dolanmiu).
