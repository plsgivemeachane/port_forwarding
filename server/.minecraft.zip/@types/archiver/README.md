# Installation
> `npm install --save @types/archiver`

# Summary
This package contains type definitions for archiver (https://github.com/archiverjs/node-archiver).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/archiver.

### Additional Details
 * Last updated: Wed, 23 Oct 2024 03:36:41 GMT
 * Dependencies: [@types/readdir-glob](https://npmjs.com/package/@types/readdir-glob)

# Credits
These definitions were written by [ Esri
//                  Dolan Miu](https://github.com/dolanmiu), [Crevil](https://github.com/crevil), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
